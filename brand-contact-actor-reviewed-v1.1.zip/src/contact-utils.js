const TARGET = /(?:^|[._+\-])(?:influencers?|creators?|partnerships?|collabs?|collaborations?|marketing|affiliates?|ambassadors?|sponsorships?)(?:[._+\-]|$)/i;
const PR = /(?:^|[._+\-])(?:press|pr|media|publicrelations|communications?)(?:[._+\-]|$)/i;
const BAD = /(?:^|[._+\-])(?:support|customerservice|care|returns|refunds|privacy|legal|abuse|security|jobs|careers|billing|webmaster|noreply|no-reply)(?:[._+\-]|$)/i;
const ROLE_TARGET = /influenc|creator|partnership|collab|brand partnership|marketing|affiliate|ambassador|sponsorship/i;
const ROLE_PR = /public relations|\bpr\b|press|media relations|communication/i;
const ROLE_BAD = /customer service|customer support|tech(?:nical)? support|billing|finance|accounting|legal|security|human resources|recruit|sales support/i;
export const clean = x => String(x ?? '').trim();
export function scoreEmail(email, position = '', department = '') {
  const local = clean(email).toLowerCase().split('@')[0] ?? '';
  const role = `${clean(position)} ${clean(department)}`;
  let score = TARGET.test(local) ? 95 : (ROLE_TARGET.test(role) ? 85 : ((PR.test(local)||ROLE_PR.test(role)) ? 45 : 10));
  if (/^(hello|info|contact|general|team)$/.test(local)) score = Math.max(score, 15);
  if (BAD.test(local) || ROLE_BAD.test(role)) score -= 100;
  return score;
}
export function isRelevant(email, position = '', department = '') { return scoreEmail(email, position, department) >= 60; }
export function parseCsv(src) {
  const s = clean(src).replace(/^\uFEFF/, ''); let rows = [], row = [], val = '', quoted = false;
  for (let i = 0; i < s.length; i++) {
    const ch = s[i];
    if (ch === '"') { if (quoted && s[i+1] === '"') { val += '"'; i++; } else quoted = !quoted; }
    else if (ch === ',' && !quoted) { row.push(val); val = ''; }
    else if ((ch === '\n' || ch === '\r') && !quoted) { if (ch === '\r' && s[i+1] === '\n') i++; row.push(val); if (row.some(x => x.trim())) rows.push(row); row = []; val = ''; }
    else val += ch;
  }
  row.push(val); if (row.some(x=>x.trim())) rows.push(row);
  if (!rows.length) return [];
  const header = rows.shift().map(x=>x.toLowerCase().trim());
  const col = names => header.findIndex(h=>names.includes(h));
  const b = col(['brand','name','company']); const w=col(['website','domain','url','site']);
  if (b < 0 && w < 0) throw new Error('CSV needs a brand/name/company and/or website/domain/url/site column');
  return rows.map(r=>({brand:b>=0 ? clean(r[b]) : '',website:w>=0 ? clean(r[w]) : ''})).filter(r=>r.brand||r.website);
}
export function toCsv(headers, records) {
  return '\uFEFF'+[headers.join(','), ...records.map(r=>headers.map(k=>'"'+clean(r[k]).replace(/"/g,'""')+'"').join(','))].join('\r\n');
}
export function normalizeSocial(url, platform) {
  try {
    const u = new URL(url); let hostname=u.hostname.toLowerCase().replace(/^www\./,'');
    if (platform==='instagram' && hostname==='instagram.com') {
      let p=u.pathname.split('/').filter(Boolean);
      if (p.length!==1 || !/^[\w.]{1,30}$/.test(p[0]) || /^(p|reel|reels|explore|stories|accounts|about|direct|tv|share)$/.test(p[0]))return '';
      return `https://www.instagram.com/${p[0]}/`;
    }
    if (platform==='tiktok' && hostname==='tiktok.com') {
      let p=u.pathname.split('/').filter(Boolean);
      if (p.length!==1 || !/^@[\w.]{2,24}$/.test(p[0]))return '';
      return `https://www.tiktok.com/${p[0]}`;
    }
    if (platform==='linkedin' && hostname==='linkedin.com') {
      let p=u.pathname.split('/').filter(Boolean);
      if (p.length!==2 || !['company','school'].includes(p[0]) || !/^[a-z0-9_%\-.]+$/i.test(p[1]))return '';
      return `https://www.linkedin.com/${p[0]}/${p[1]}/`;
    }
  } catch { /* invalid URL */ }
  return '';
}
export function worstHunterCost(mode, emails) { return mode==='data_platform' ? Math.ceil(emails/10) : emails; }
export function normalizedDepartmentFilter(value) {
  const allowed=new Set(['executive','it','finance','management','sales','legal','support','hr','marketing','communication','education','design','health','operations','product','research','consulting','administrative','procurement']);
  let a=clean(value).toLowerCase().split(',').map(x=>x.trim()).filter(Boolean);
  for (const d of a) if (!allowed.has(d)) throw new Error(`Unsupported Hunter department filter: ${d}`);
  return [...new Set(a)].join(',');
}
