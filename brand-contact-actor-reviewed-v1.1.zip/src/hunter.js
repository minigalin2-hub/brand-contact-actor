import { clean, scoreEmail, normalizedDepartmentFilter } from './contact-utils.js';
const BASE='https://api.hunter.io/v2';
async function hunterGet(url, key, timeoutMs=20000) {
  const c=new AbortController(); const timer=setTimeout(()=>c.abort(),timeoutMs);
  try {
    const response=await fetch(url,{signal:c.signal,headers:{'X-API-KEY':key,accept:'application/json'}});
    let data; try { data=await response.json(); } catch { data={}; }
    if (!response.ok) {
      const message=data?.errors?.[0]?.details || data?.errors?.[0]?.id || `HTTP ${response.status}`;
      const e=new Error(`Hunter ${response.status}: ${message}`); e.status=response.status; throw e;
    }
    return { data, creditsUsed: Number(response.headers.get('X-Credits-Used') ?? NaN), creditUnit:response.headers.get('X-Credits-Unit') || '' };
  } finally { clearTimeout(timer); }
}
export async function domainFinder(company, key) {
  const u=new URL(`${BASE}/domain-finder`); u.searchParams.set('company',company);u.searchParams.set('limit','3');u.searchParams.set('perfect_match','true');
  const res=await hunterGet(u,key);
  const entries=Array.isArray(res.data?.data) ? res.data.data : (res.data?.data ? [res.data.data]: []);
  return entries.map(x=>({domain:clean(x.domain),company_name:clean(x.company_name)})).filter(x=>x.domain);
}
export async function domainSearch(domain,key,limit,departmentFilter) {
  const u=new URL(`${BASE}/domain-search`); u.searchParams.set('domain',domain);u.searchParams.set('limit',String(limit));
  const department=normalizedDepartmentFilter(departmentFilter);
  if (department)u.searchParams.set('department',department);
  const resp=await hunterGet(u,key);
  const contacts=(resp.data?.data?.emails||[]).map(e=>({
    email:clean(e.value).toLowerCase(),origin:'hunter',source:'Hunter Domain Search',
    position:clean(e.position),department:clean(e.department),verification:clean(e.verification?.status || 'unknown'),
    confidence:e.confidence ?? null,provenance:clean(e.provenance),score:scoreEmail(e.value,e.position,e.department)
  })).filter(x=>x.email);
  return { contacts,creditsUsed:resp.creditsUsed,creditUnit:resp.creditUnit };
}
