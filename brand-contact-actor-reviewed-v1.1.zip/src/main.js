import { Actor } from 'apify';
import * as cheerio from 'cheerio';
import { getDomain } from 'tldts';
import { clean, scoreEmail, isRelevant, parseCsv, toCsv, normalizeSocial, worstHunterCost, normalizedDepartmentFilter } from './contact-utils.js';
import { domainFinder, domainSearch } from './hunter.js';

const EMAIL=/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
const LINK_HINT=/contact|about|press|media|partner|collab|influenc|affiliate|creator|team|ambassador|brand|pr\b/i;
const FALLBACK_PATHS=['/pages/contact','/pages/contact-us','/contact','/contact-us','/about','/press','/partnerships','/influencers','/affiliate','/pages/about-us'];
function domainOf(value) {
  try {const u=new URL(/^https?:\/\//i.test(clean(value))?clean(value):`https://${clean(value)}`);
    if (!['http:','https:'].includes(u.protocol)||u.username||u.password)return '';
    return getDomain(u.hostname,{allowPrivateDomains:false})||'';
  } catch{return '';}
}
function emailIsWellFormed(email) { return /^[\w.%+\-]+@[a-z\d.-]+\.[a-z]{2,}$/i.test(email) && email.length <= 120; }
async function fetchHtml(url, timeoutMs=10000){
  const c=new AbortController(); const timer=setTimeout(()=>c.abort(),timeoutMs);
  try {const r=await fetch(url,{signal:c.signal,redirect:'follow',headers:{'user-agent':'Mozilla/5.0 (compatible; BrandContactResearchBot/1.1)'}});
    if(!r.ok || !(r.headers.get('content-type')||'').toLowerCase().includes('text/html'))return null;
    const size=Number(r.headers.get('content-length')||0);if(size>2_000_000)return null;
    return {html:(await r.text()).slice(0,1_500_000),url:r.url};
  } catch{return null;}finally{clearTimeout(timer);}
}
function addEmail(result, raw, source){
  const address=clean(raw).toLowerCase().replace(/^mailto:/,'').replace(/[.,;:)\]]+$/,'');
  if(!emailIsWellFormed(address))return;
  if(!result.emails.some(e=>e.email===address))result.emails.push({email:address,source,origin:'website',score:scoreEmail(address),verification:'not_verified',position:'',department:''});
}
async function scrapeWebsite(domain,maxPages){
  const base=`https://${domain}/`; const out={emails:[],instagram:'',tiktok:'',linkedin:'',socialSources:{},pages:[],status:'no_html'};
  const queue=[base];const queued=new Set(queue);const visited=new Set();let fallbackAdded=false;
  while(queue.length && out.pages.length < maxPages && visited.size < maxPages*3){
    const candidate=queue.shift();if(visited.has(candidate))continue;visited.add(candidate);
    const page=await fetchHtml(candidate);
    if(!page){if(!fallbackAdded && candidate===base){fallbackAdded=true;for(const path of FALLBACK_PATHS){let p=new URL(path,base).href;if(!queued.has(p)){queue.push(p);queued.add(p);}}}continue;}
    if(domainOf(page.url)!==domain)continue; // Do not follow a redirect to an unrelated website.
    out.status='scraped';out.pages.push(page.url);
    const $=cheerio.load(page.html);$('script,style,noscript').remove();
    const text=$('body').text(); const hrefs=$('a[href]').map((_,el)=>$(el).attr('href')).get();
    const mailtos=hrefs.filter(x=>/^mailto:/i.test(x)).map(x=>x.replace(/^mailto:/i,'').split('?')[0]);
    const found=[...(text.match(EMAIL)||[]),...mailtos];
    for(const s of found) addEmail(out,s,page.url);
    const next=[];
    for(const href of hrefs){
      let absolute;try {absolute=new URL(href,page.url);}catch{continue;}
      for(const social of ['instagram','tiktok','linkedin']){
        const value=normalizeSocial(absolute.href,social);
        if(value&&!out[social]){out[social]=value;out.socialSources[social]=page.url;}
      }
      if(!['https:','http:'].includes(absolute.protocol)||domainOf(absolute.href)!==domain)continue;
      absolute.hash='';const sameSite=absolute.href;
      if(LINK_HINT.test(absolute.pathname) && !queued.has(sameSite)){queued.add(sameSite);next.push(sameSite);}
    }
    queue.unshift(...next.slice(0,Math.max(0,maxPages*2-queue.length))); // Prefer actual website navigation.
    if(!fallbackAdded){fallbackAdded=true;for(const path of FALLBACK_PATHS){let p=new URL(path,base).href;if(!queued.has(p)){queue.push(p);queued.add(p);}}}
  }
  out.emails.sort((a,b)=>b.score-a.score);return out;
}
function cleanContactRows(contacts){
  const map=new Map();for(const c of contacts){if(!c.email)continue;const old=map.get(c.email);
    if(!old || c.score>old.score || (old.origin==='hunter' && c.origin==='website'))map.set(c.email,c);
  }return [...map.values()].sort((a,b)=>b.score-a.score);
}
function hasLikelyWebsite(value){return /^(?:https?:\/\/)?(?:[\w\-]+\.)+[a-z]{2,}(?:\/|$)/i.test(clean(value));}

await Actor.init();
try{
  const input=await Actor.getInput()||{};
  const key=clean(input.hunterApiKey||process.env.HUNTER_API_KEY);
  const dry=input.dryRun!==false;const useHunter=input.useHunter!==false;
  const mode=input.hunterCreditMode==='data_platform'?'data_platform':'all_in_one';
  const maxPages=Math.max(1,Math.min(20,Number(input.maxPagesPerBrand??8)));
  const maxEmails=Math.max(1,Math.min(10,Number(input.maxHunterEmailsPerBrand??5)));
  const creditCap=Math.max(0,Number(input.maxHunterCredits??5));
  const domainCap=Math.max(0,Number(input.maxHunterDomains??5));
  const departments=normalizedDepartmentFilter(input.hunterDepartments??'marketing,communication');
  const lines=clean(input.brands).split(/\r?\n/).map(s=>s.trim()).filter(Boolean);
  let items=lines.map(s=>({brand:hasLikelyWebsite(s)?'':s,website:hasLikelyWebsite(s)?s:''}));
  if(input.csvUrl){const url=new URL(input.csvUrl);if(url.protocol!=='https:'||domainOf(url.href)==='')throw new Error('csvUrl must be a public HTTPS address');
    const c=new AbortController();const timeout=setTimeout(()=>c.abort(),15000);
    try{const r=await fetch(url,{signal:c.signal});if(!r.ok)throw new Error(`CSV HTTP ${r.status}`);
      if(Number(r.headers.get('content-length')||0)>5_000_000)throw new Error('CSV too large');
      items.push(...parseCsv((await r.text()).slice(0,5_000_000)));
    }finally{clearTimeout(timeout);}
  }
  if(!items.length)throw new Error('Enter brand names/domains/URLs or a public CSV URL.');
  const results=[],pending=[],allContacts=[];
  const siteCache=new Map(),hunterCache=new Map(),seen=new Set();
  let creditsUsed=0,estimatedCostFallback=0,hunterDomains=0,quotaStop=false;
  const pendingRecord=async(p)=>{pending.push(p);};
  for(const item of items){
    let domain=domainOf(item.website),brand=clean(item.brand)||domain;
    let domainResolution='provided_website';
    if(!domain && hasLikelyWebsite(brand)){domain=domainOf(brand);domainResolution='provided_domain';}
    if(!domain && key){
      try{const guesses=await domainFinder(brand,key);if(guesses.length){domain=domainOf(guesses[0].domain);domainResolution='hunter_domain_finder_review_required';}}
      catch(e){console.warn(`Domain Finder failed for ${brand}: ${String(e.message).slice(0,100)}`);}
    }
    if(!domain){let record={brand,domain:'',status:'domain_unresolved',domain_resolution:domainResolution,contacts:[],instagram:'',tiktok:'',linkedin:''};
      results.push(record);await Actor.pushData(record);await pendingRecord({brand,domain:'',reason:'domain_unresolved'});continue;
    }
    if(seen.has(`${brand.toLowerCase()}|${domain}`))continue;seen.add(`${brand.toLowerCase()}|${domain}`);
    if(!siteCache.has(domain))siteCache.set(domain,await scrapeWebsite(domain,maxPages));
    const scraped=siteCache.get(domain);let contacts=[...scraped.emails];let status=scraped.status;
    if(!contacts.some(x=>isRelevant(x.email,x.position,x.department)) && useHunter){
      const needsManualReview=domainResolution==='hunter_domain_finder_review_required'&&!input.allowHunterForResolvedNames;
      const maxCallCost=worstHunterCost(mode,maxEmails);
      if(!key)status='hunter_key_missing';
      else if(needsManualReview)status='review_domain_before_paid_hunter';
      else if(dry)status='hunter_dry_run';
      else if(quotaStop)status='hunter_quota_exhausted';
      else if(hunterCache.has(domain)){const r=hunterCache.get(domain);contacts.push(...r.contacts);status='hunter_cached';}
      else if(hunterDomains>=domainCap || creditsUsed+estimatedCostFallback+maxCallCost>creditCap)status='hunter_budget_limit';
      else{
        try{
          const found=await domainSearch(domain,key,maxEmails,departments);
          hunterDomains++;
          if(!Number.isFinite(found.creditsUsed))estimatedCostFallback+=maxCallCost;
          else creditsUsed+=found.creditsUsed;
          hunterCache.set(domain,found);contacts.push(...found.contacts);
          status=found.contacts.length?'hunter_found':'hunter_no_results';
          if(creditsUsed+estimatedCostFallback>creditCap)quotaStop=true;
        }catch(e){status=`hunter_error: ${String(e.message).slice(0,100)}`;if(e.status===429)quotaStop=true;}
      }
      if(!['hunter_found','hunter_cached'].includes(status))await pendingRecord({brand,domain,reason:status});
    }
    contacts=cleanContactRows(contacts);
    for(const c of contacts){const row={brand,domain,...c};allContacts.push(row);}
    const rec={brand,domain,website:`https://${domain}`,domain_resolution:domainResolution,instagram:scraped.instagram,tiktok:scraped.tiktok,linkedin:scraped.linkedin,social_sources:scraped.socialSources,status,target_email_found:contacts.some(x=>x.score>=60),best_email:contacts[0]?.email||'',contacts,pages_scanned:scraped.pages};
    results.push(rec);await Actor.pushData(rec);
  }
  const brandFlat=results.map(r=>({brand:r.brand,domain:r.domain,website:r.website,domain_resolution:r.domain_resolution,best_email:r.best_email,instagram:r.instagram,tiktok:r.tiktok,linkedin:r.linkedin,instagram_source:r.social_sources?.instagram,tiktok_source:r.social_sources?.tiktok,linkedin_source:r.social_sources?.linkedin,status:r.status,target_email_found:r.target_email_found,emails:(r.contacts||[]).map(c=>c.email).join('; ')}));
  const brandsCols=['brand','domain','website','domain_resolution','best_email','instagram','tiktok','linkedin','instagram_source','tiktok_source','linkedin_source','status','target_email_found','emails'];
  const contactCols=['brand','domain','email','origin','source','position','department','verification','score','confidence','provenance'];
  await Actor.setValue('BRANDS_CSV',toCsv(brandsCols,brandFlat),{contentType:'text/csv; charset=utf-8'});
  await Actor.setValue('CONTACTS_CSV',toCsv(contactCols,allContacts),{contentType:'text/csv; charset=utf-8'});
  await Actor.setValue('HUNTER_PENDING_CSV',toCsv(['brand','domain','reason'],pending),{contentType:'text/csv; charset=utf-8'});
  await Actor.setValue('SUMMARY',{brands:results.length,brands_with_email:results.filter(r=>r.contacts?.length).length,brands_with_target_email:results.filter(r=>r.target_email_found).length,hunter_domains_queried:hunterDomains,hunter_credits_reported:creditsUsed,hunter_max_cost_reserve_if_no_header:estimatedCostFallback,hunter_credit_mode:mode,dry_run:dry,pending_hunter:pending.length});
  console.log(`Processed ${results.length} brands; Hunter queries ${hunterDomains}; credits reported ${creditsUsed}; unreported fallback reserve ${estimatedCostFallback}; dry run ${dry}`);
}finally{await Actor.exit();}
