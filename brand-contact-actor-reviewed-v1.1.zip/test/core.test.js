import test from 'node:test';
import assert from 'node:assert/strict';
import { scoreEmail, isRelevant, parseCsv, normalizeSocial, worstHunterCost, normalizedDepartmentFilter, toCsv } from '../src/contact-utils.js';
import { domainSearch, domainFinder } from '../src/hunter.js';

test('brand in domain does not accidentally count as a marketing role',()=>{
  assert.equal(isRelevant('hello@brand.com'), false);
  assert.equal(isRelevant('care@brand.com'), false);
  assert.equal(isRelevant('press@brand.com'), false);
  assert.equal(scoreEmail('press@brand.com'), 45);
  assert.equal(isRelevant('alice@brand.com','Influencer Marketing Manager','marketing'), true);
  assert.ok(scoreEmail('support@brand.com') < 60);
});
test('robust CSV quoted newlines and BOM',()=>{
  const items=parseCsv('\uFEFFbrand,website\n"Brand, Inc.","https://brand.com"\n"Brand Two",example.org\n');
  assert.deepEqual(items,[{brand:'Brand, Inc.',website:'https://brand.com'},{brand:'Brand Two',website:'example.org'}]);
  assert.deepEqual(parseCsv('website\nhttps://example.org'),[{brand:'',website:'https://example.org'}]);
  assert.match(toCsv(['a'],[{a:'hi "x"'}]),/"hi ""x"""/);
});
test('normalize real account URLs and reject posts',()=>{
  assert.equal(normalizeSocial('https://www.instagram.com/official.brand/?igsh=x','instagram'),'https://www.instagram.com/official.brand/');
  assert.equal(normalizeSocial('https://www.instagram.com/p/ABC123','instagram'),'');
  assert.equal(normalizeSocial('https://www.tiktok.com/@brand/video/123','tiktok'),'');
  assert.equal(normalizeSocial('https://www.tiktok.com/@brand','tiktok'),'https://www.tiktok.com/@brand');
  assert.equal(normalizeSocial('https://www.linkedin.com/company/brandname/','linkedin'),'https://www.linkedin.com/company/brandname/');
});
test('conservative credit accounting and department validation',()=>{
  assert.equal(worstHunterCost('all_in_one',5),5);
  assert.equal(worstHunterCost('data_platform',5),1);
  assert.equal(normalizedDepartmentFilter('marketing,communication,marketing'),'marketing,communication');
  assert.throws(()=>normalizedDepartmentFilter('marketing,spam'));
});
test('Hunter sends key in header, uses department filter and reads credit header',async()=>{
  const old=globalThis.fetch;
  globalThis.fetch=async (url, init)=>{
    const u=new URL(url);assert.equal(u.searchParams.get('domain'),'brand.com');assert.equal(u.searchParams.get('limit'),'5');
    assert.equal(u.searchParams.get('department'),'marketing,communication');assert.equal(u.searchParams.has('api_key'),false);
    assert.equal(init.headers['X-API-KEY'],'test-secret');
    return {ok:true,status:200,headers:new Headers({'X-Credits-Used':'2','X-Credits-Unit':'credit'}),json:async()=>({data:{emails:[{value:'partner@brand.com',position:'Influencer Lead',department:'marketing',verification:{status:'valid'},confidence:92}]}})};
  };
  try { const res=await domainSearch('brand.com','test-secret',5,'marketing,communication');assert.equal(res.creditsUsed,2);assert.equal(res.contacts.length,1);assert.equal(res.contacts[0].verification,'valid');}
  finally{globalThis.fetch=old;}
});
test('Hunter free Domain Finder handles documented array data',async()=>{
  const old=globalThis.fetch;
  globalThis.fetch=async(url,init)=>{
    assert.ok(String(url).includes('/domain-finder?'));assert.equal(init.headers['X-API-KEY'],'test-secret');
    return {ok:true,headers:new Headers(),json:async()=>({data:[{domain:'brand.com',company_name:'Brand'}]})};
  };
  try{const suggestions=await domainFinder('Brand','test-secret');assert.deepEqual(suggestions,[{domain:'brand.com',company_name:'Brand'}]);}
  finally{globalThis.fetch=old;}
});
