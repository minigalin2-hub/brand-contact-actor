# Brand Contact Enricher — reviewed v1.1

## Inputs and output

Enter **one official domain / URL per line** in the `brands` field, or provide a public HTTPS `csvUrl` with `brand,website` columns. Brand names alone use Hunter's free Domain Finder if a key is available; this match is **not automatically trusted for paid calls**.

1. The Actor requests public HTML pages of the provided official website (home page, relevant navigation, contact/press pages).
2. It extracts publicly displayed email addresses and account links to Instagram, TikTok, and LinkedIn.
3. An email is classified as *likely relevant* only when the email local part or the Hunter's contact position/department implies influencer/creator/marketing/partnerships. Press/PR is kept as secondary, not sufficient to skip Hunter; support/legal etc. are deprioritized.
4. With `dryRun=false`, `useHunter=true`, a secret Hunter key, and no matching email found on the site, it performs **one Hunter Domain Search per unique domain**, with `department=marketing,communication` by default and `limit` no more than 5.
5. Results are deduplicated. The **run's default dataset** and `BRANDS_CSV` contain one brand row; `CONTACTS_CSV` contains all known emails; `HUNTER_PENDING_CSV` lists unresolved cases. CSV records are stored in the run's **default Key-value store** (no named datasets that accidentally accumulate across runs).

## Safe first run

- Set `brands` to 2–5 official URLs, not just names.
- `dryRun=true` (default): Hunter Domain Search will not be called, **0 Hunter search credits**. It may call free Domain Finder if you provide names and a key.
- `maxPagesPerBrand=8`.
- Check `BRANDS_CSV`, `CONTACTS_CSV`, `HUNTER_PENDING_CSV`.
- Then, if desired, set `dryRun=false`, `maxHunterEmailsPerBrand=5`, `maxHunterCredits=5`, `maxHunterDomains=1`, `hunterCreditMode=all_in_one` for a one-domain paid test. If your account is explicitly on Hunter Data Platform billing, select `data_platform` instead.
- Leave `allowHunterForResolvedNames=false` unless you personally checked guessed company domains.

## Installation

The easiest reproducible deployment for a ZIP project is the [official Apify CLI](https://docs.apify.com/actors/development/deployment):

1. Unzip **this v1.1 archive**.
2. Install the Apify CLI, log in using `apify login` (follow instructions at https://docs.apify.com/cli/docs/quick-start).
3. Open a terminal in the project directory (the folder that contains `.actor/actor.json`).
4. Run `apify push`. It will create/update the Actor and build it on Apify.
5. Go to the Actor's **Input** screen, set fields, click **Start**.

Alternatively, use **Source → Web IDE** and copy the files into the corresponding paths. Do not assume the Console has a direct ZIP-upload action in every interface variant.

## Credits — important

Hunter's current rules vary by plan:
- All-in-one: ordinary **Domain Search can cost up to 1 credit per email revealed**.
- Data Platform: ordinary **Domain Search costs 1 search credit per up to 10 emails per domain**.
- Bulk Domain Search has different economics, and **our Actor uses API Domain Search, not Bulk Domain Search**.

The Actor reserves worst-case credits **before every request** according to the selected `hunterCreditMode`, then records actual `X-Credits-Used` from the API response, falling back to reserved cost if the header is missing. This prevents overspend under the documented mode, but is not a contractual financial cap if Hunter changes pricing or other jobs run concurrently. When budget is too small (e.g. 2 credits for an All-in-one request of up to 5 emails), Hunter is skipped. You can change `maxHunterEmailsPerBrand` to 1–2 to test with smaller credit caps. Repeated requests may be free within a billing period; headers give actual spending.

## Limitations

- HTML fetching is not a browser; JS-rendered sites, anti-bot measures and robots restrictions reduce coverage. No circumvention of access controls.
- Instagram, TikTok and LinkedIn are extracted **only from links on the official site**. Empty fields mean *not seen*, not nonexistence. International or parent-company pages may need manual review.
- `maxHunterEmailsPerBrand=5` limits *returned* emails, **not 5 target emails**. The default `department` filter helps but some companies lack department classification.
- No verification of website emails and no real-time delivery testing. Hunter's prior `valid` status is not guaranteed delivery.
- Official domain and suitability for paid influencer campaigns still require manual review.
- No automatic email sending. Ensure lawful, relevant outreach and unsubscribe/opt-out handling.
- This package has been syntax-checked and its helpers unit-tested, but **has not been built on Apify nor tested with a real Hunter account**.

## Checked locally

`npm test` (helper unit tests with mocked Hunter responses), `node --check` (JavaScript syntax), and JSON parsing. Live Apify build, real-site crawling and Hunter billing have **not** yet been tested.
